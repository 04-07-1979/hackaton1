// Абстракция данных пользователя
protocol UserData {
    var userName: String { get }            //Имя пользователя
    var userCardId: String { get }          //Номер карты
    var userCardPin: Int { get }            //Пин-код
    var userCash: Float { get set}          //Наличные пользователя
    var userBankDeposit: Float { get set}   //Банковский депозит
    var userPhone: String { get }           //Номер телефона
    var userPhoneBalance: Float { get set}  //Баланс телефона
}

class User: UserData{
    let userName: String         //Имя пользователя
    let userCardId: String       //Номер карты
    let userCardPin: Int         //Пин-код
    var userCash: Float          //Наличные пользователя
    var userBankDeposit: Float   //Банковский депозит
    let userPhone: String        //Номер телефона
    var userPhoneBalance: Float  //Баланс телефона

    init(name: String, cardId: String, cardPin: Int, cash: Float, bankDeposit: Float, phone: String, phoneBalance: Float){
        userName = name
        userCardId = cardId
        userCardPin = cardPin
        userCash = cash
        userBankDeposit = bankDeposit
        userPhone = phone
        userPhoneBalance = phoneBalance
    }
}
var bankUserOne:UserData = User(name: "Vasiliy Pupesku", cardId: "1234 2345 0987 9876", cardPin: 6666, cash: 999.9, bankDeposit: 123456.78, phone: "+7 900 111 22 33", phoneBalance: 55.3)



// Тексты ошибок
public enum TextErrors: String {
    case NotEnoughCash = "Не достаточно наличных"
    case NotEnoughDeposit = "Не достаточно средств на депозите"
    case WrongCardPin = "Неверный пин"
    case WrongPhone = "Неверный номер телефона"
    case WrongCardId = "Неверный номер карты"
}
 
// Виды операций, выбранных пользователем (подтверждение выбора)
public enum DescriptionTypesAvailableOperations: String {
    case CheckBalance = "Проверка баланса"
    case WithdrawCash = "Снять наличные"
    case Deposit = "Пополнить депозит"
    case TopUpPhoneBalance = "Пополнить баланс телефона"
}

// Действия, которые пользователь может выбирать в банкомате (имитация кнопок)
public enum UserActions {
    case CheckBalance
    case WithdrawCash
    case Deposit
    case TopUpPhoneBalance
}

// Способ оплаты/пополнения наличными или через депозит
public enum PaymentMethod {
    case Cash(amount: Double)
    case Deposit(amount: Double)
}

// Банкомат, с которым мы работаем, имеет общедоступный интерфейс sendUserDataToBank
class ATM {
    private let userCardId: String
    private let userCardPin: Int
    private var someBank: BankApi
    private let action: UserActions
    private var paymentMethod: PaymentMethod?
 
    init(userCardId: String, userCardPin: Int, someBank: BankApi, action: UserActions, paymentMethod: PaymentMethod? = nil){
        self.userCardId = userCardId
        self.userCardPin = userCardPin
        self.someBank = someBank
        self.action = action
        self.paymentMethod = paymentMethod
        
        sendUserDataToBank(userCardId: userCardId, userCardPin: userCardPin, actions: action, payment: paymentMethod )
    }
}

public func sendUserDataToBank(userCardId: String, userCardPin: Int, actions: UserActions, payment: PaymentMethod?) {
// основной модуль - проверка введенных данных пользователя и т.д. из перечисления кодов ошибок

    let bankClient = BankServer()
    
    if bankClient.checkCurrentUser(userCardId: userCardId, userCardPin: userCardPin) {
        print("user check completed")
        
        switch actions {
        case .CheckBalance:
            bankClient.showUserBalance()
        case .Deposit:
            bankClient.putCashDeposit(topUp: PaymentMethod.Cash(amount: 33))
        case .TopUpPhoneBalance:
            bankClient.topUpPhoneBalanceCash(pay: PaymentMethod.Cash(amount: 44))
        case .WithdrawCash:
            bankClient.getCashFromDeposit(cash: )
        }
    }
}

let aaa = ATM(userCardId: "1221 1111 2222 3333", userCardPin: 6666, someBank: BankServer, action: .CheckBalance)


// Протокол по работе с банком предоставляет доступ к данным пользователя зарегистрированного в банке
protocol BankApi {
    func showUserBalance()
    func showUserToppedUpMobilePhoneCash(cash: Float)
    func showUserToppedUpMobilePhoneDeposite(deposit: Float)
    func showWithdrawalDeposit(cash: Float)
    func showTopUpAccount(cash: Float)
    func showError(error: TextErrors)
// вспомогательные методы
    func checkUserPhone(phone: String) -> Bool
    func checkMaxUserCash(cash: Float) -> Bool
    func checkMaxAccountDeposit(withdraw: Float) -> Bool
    func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool
 
    mutating func topUpPhoneBalanceCash(pay: Float)
    mutating func topUpPhoneBalanceDeposit(pay: Float)
    mutating func getCashFromDeposit(cash: Float)
    mutating func putCashDeposit(topUp: Float)
}

class BankServer: BankApi {
    
    func showUserBalance() {print("Баланс депозита счета клиента \(bankUserOne.userName) составляет \(bankUserOne.userBankDeposit)")}
    func showUserToppedUpMobilePhoneCash(cash: Float) {print("Сумма пополнения наличными: \(cash). Баланс счета мобильного телефона клиента \(bankUserOne.userName) составляет \(bankUserOne.userPhoneBalance)")}
    func showUserToppedUpMobilePhoneDeposite(deposit: Float) {print("Сумма пополнения с депозита: \(deposit). Баланс счета мобильного телефона клиента \(bankUserOne.userName) составляет \(bankUserOne.userPhoneBalance)")}
    func showWithdrawalDeposit(cash: Float) {print("Сумма снятия наличных с депозита: \(cash). Остаток по депозиту клиента \(bankUserOne.userName) составляет \(bankUserOne.userBankDeposit)")}
    func showTopUpAccount(cash: Float) {print("Сумма пополнения счета: \(cash). Остаток по депозиту клиента \(bankUserOne.userName) составляет \(bankUserOne.userBankDeposit)")}
    func showError(error: TextErrors) {print("Возникла ошибка: \(error)")}
    func checkUserPhone(phone: String) -> Bool {return phone == bankUserOne.userPhone}
    func checkMaxUserCash(cash: Float) -> Bool {return cash <= bankUserOne.userCash}
    func checkMaxAccountDeposit(withdraw: Float) -> Bool {return withdraw <= bankUserOne.userBankDeposit}
    func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool {return userCardPin == bankUserOne.userCardPin && userCardId == bankUserOne.userCardId}

    func topUpPhoneBalanceCash(pay: Float) {
        if checkMaxUserCash(cash: pay){
            bankUserOne.userCash -= pay
            bankUserOne.userPhoneBalance += pay
            print("Сумма пополнения телефона наличными: \(pay). Остаток наличности \(bankUserOne.userCash), баланс телефона \(bankUserOne.userPhoneBalance)")}
    }
    func topUpPhoneBalanceDeposit(pay: Float) {
        if checkMaxAccountDeposit(withdraw: pay){
            bankUserOne.userBankDeposit -= pay
            bankUserOne.userPhoneBalance += pay
            print("Сумма пополнения телефона со счета: \(pay). Остаток на счете: \(bankUserOne.userBankDeposit), баланс телефона \(bankUserOne.userPhoneBalance)")}
    }
    func getCashFromDeposit(cash: Float) {
        if checkMaxAccountDeposit(withdraw: cash){
            bankUserOne.userBankDeposit -= cash
            bankUserOne.userCash += cash
            print("Сумма снятия наличных со счета: \(cash). Остаток на счете: \(bankUserOne.userBankDeposit), баланс наличности \(bankUserOne.userCash)")}
    }
    func putCashDeposit(topUp: Float) {
        if checkMaxUserCash(cash: topUp){
            bankUserOne.userBankDeposit += topUp
            bankUserOne.userCash -= topUp
            print("Сумма внесения наличных на счет: \(topUp). Остаток на счете: \(bankUserOne.userBankDeposit), баланс наличности \(bankUserOne.userCash)")}
    }
}

